live link :https://colab-code.vercel.app/

ColabCode is a collaborative coding platform that allows users to log in, submit challenges, and solve coding problems . It features a clean UI, problem dashboards, a code editor, and discussion forums for each problem. The platform is built using React.js, Node.js, Express.js, and MongoDB, ensuring a seamless coding experience. 
